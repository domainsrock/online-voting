<div class="table-responsive" style="background: white; padding: 10px; border-radius: 10px">
    <table id="example" class="table table-striped">
        <thead class="bg-primary">
            <tr>
                <th>Positions ID</th>
                <th>Positions Name</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($positions as $positions_item): ?>
                <tr>
                    <td><?php echo $positions_item['positions_id']; ?></td>
                    <td><?php echo $positions_item['positions_name']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>