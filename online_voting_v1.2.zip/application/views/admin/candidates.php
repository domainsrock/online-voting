<div class="table-responsive" style="background: white; padding: 10px; border-radius: 10px">
    <table id="example" class="table table-striped">
        <thead class="bg-primary">
            <tr>
                <th>Candidates ID</th>
                <th>Candidates Name</th>
                <th>Candidates Parties</th>
                <th>Candidates Positions</th>
                <th>Candidates Votes Count</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($candidates as $candidates_item): ?>
                <tr>
                    <td><?php echo $candidates_item['candidates_id']; ?></td>
                    <td><?php echo $candidates_item['candidates_name']; ?></td>
                    <td><?php echo $candidates_item['candidates_parties']; ?></td>
                    <td><?php echo $candidates_item['candidates_positions']; ?></td>
                    <td><?php echo $candidates_item['candidates_usersvote']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>