<div class="table-responsive" style="background: white; padding: 10px; border-radius: 10px">
    <table id="example" class="table table-striped">
        <thead class="bg-primary">
            <tr>
                <th>Username</th>
                <th>Password</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Phone</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Age</th>
                <th>Address</th>
                <th>Registration Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($voters as $voters_item): ?>
                <tr>
                    <td><?php echo $voters_item['username']; ?></td>
                    <td><?php echo $voters_item['password']; ?></td>
                    <td><?php echo $voters_item['fname']; ?></td>
                    <td><?php echo $voters_item['lname']; ?></td>
                    <td><?php echo $voters_item['phone']; ?></td>
                    <td><?php echo $voters_item['gender']; ?></td>
                    <td><?php echo $voters_item['birthday']; ?></td>
                    <td><?php echo $voters_item['age']; ?> Years</td>
                    <td><?php echo $voters_item['address']; ?></td>
                    <td><?php echo $voters_item['regdate']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>