<div class="container">
    <br style="line-height: 200px"/>
    <?php echo validation_errors(); echo $response; ?>    
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title">Administrator Login</h3>
        </div>
        <div class="panel-body">
            <?php echo form_open('admin/login'); ?>
                <b>Username</b>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                    <input type="text" name="admin_username" class="form-control" placeholder="Username" required/>
                </div>
                <br/>
                <b>Password</b>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="password" name="admin_password" class="form-control" placeholder="Password" required/>
                </div>
                <br/>
                <div class="form-group">
                    <input type="submit" name="admin_loginsubmit" value="Administrator SignIn" class="btn btn-block btn-success"/>
                </div>
            </form>
        </div>
    </div>
</div>