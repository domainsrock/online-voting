<div class="container">
    <br style="line-height: 100px"/>
    <?php echo validation_errors(); echo $response; ?>    
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title">Voters Registration</h3>
        </div>
        <div class="panel-body">
            <?php echo form_open('users/registration'); ?>
                <div class="row" style="margin-bottom: 10px">
                    <div class="col-xs-6">
                        <b>First Name</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-address-card"></i></span>
                            <input type="text" name="users_fname" class="form-control" placeholder="First Name" required/>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <b>Last Name</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-address-card"></i></span>
                            <input type="text" name="users_lname" class="form-control" placeholder="Last Name" required/>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-bottom: 10px">
                    <div class="col-xs-6">
                        <b>Phone Number</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                            <input type="number" name="users_phone" class="form-control" placeholder="Phone Number" required/>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <b>Date of Birth</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-address-card"></i></span>
                            <input type="date" name="users_dob" class="form-control" placeholder="Date of Birth" style="width: 100%" required/>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-bottom: 10px">
                    <div class="col-xs-6">
                        <b>Gender</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-address-card"></i></span>
                            <select name="users_genders" class="form-control" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <b>Address</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-address-card"></i></span>
                            <input type="text" name="users_address" class="form-control" placeholder="Address" required/>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-bottom: 10px">
                    <div class="col-xs-6">
                        <b>Password</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                            <input type="password" name="users_password1" class="form-control" placeholder="Password" required/>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <b>Confirm Password</b>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                            <input type="password" name="users_password2" class="form-control" placeholder="Confirm Password" required/>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="form-group">
                            <input type="submit" name="users_createaccount" value="Create Account" class="btn btn-block btn-success"/>
                        </div>
                    </div>
                </div>
            </form>

            <b>Already have Account?</b> <a href="login">Click Here for Login</a>
        </div>
    </div>
</div>