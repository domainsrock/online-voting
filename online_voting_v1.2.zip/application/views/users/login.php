<div class="container">
    <br style="line-height: 200px"/>
    <?php echo validation_errors(); echo $response; ?>    
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title">Voters Login</h3>
        </div>
        <div class="panel-body">
            <?php echo form_open('users/login'); ?>
                <b>Username</b>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                    <input type="text" name="users_username" class="form-control" placeholder="Username" required/>
                </div>
                <br/>
                <b>Password</b>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                    <input type="password" name="users_password" class="form-control" placeholder="Password" required/>
                </div>
                <br/>
                <div class="form-group">
                    <input type="submit" name="users_loginsubmit" value="SignIn" class="btn btn-block btn-success"/>
                </div>
            </form>

            <b>Don't have Account?</b> <a href="registration">Create New Account</a>
        </div>
    </div>
</div>