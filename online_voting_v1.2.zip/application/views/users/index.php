<div class="container">
    <div class="row">
        <?php foreach ($positions as $positions_item): ?>
            <div class="col-sm-4 col-xs-6" style="padding: 10px">
                <div class="bg-primary text-center" style="padding: 15px; border-radius: 15px">
                    <img src="<?php echo base_url('images/icon.png'); ?>" alt="..." width="100px" class="img-circle"/>
                    <br/>
                    <span style="font-size: 22px"><?php echo $positions_item['positions_name']; ?></span>
                    <br/>
                    <code>Vote for <?php echo $positions_item['positions_name']; ?></code>
                    <br/><br/>
                    <a href="<?php echo site_url('users/vote/'.$positions_item['positions_slug']); ?>" class="btn btn-info">View Candidates</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>