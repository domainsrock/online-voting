<div class="container">
    <div class="row">
        <?php foreach ($candidates as $candidates_item): ?>
            <div class="col-sm-4 col-xs-6" style="padding: 10px">
                <div class="bg-primary text-center" style="padding: 15px; border-radius: 15px">
                    <img src="<?php echo base_url('images/parties/'.$candidates_item['candidates_images']); ?>" alt="..." width="100px" class="img-circle"/>
                    <br/>
                    <span style="font-size: 22px"><?php echo $candidates_item['candidates_parties']; ?></span>
                    <br/>
                    <code>Vote for Your Favourites Candidates</code>
                    <br/><br/>
                    <a href="<?php echo site_url('users/votings/'.$candidates_item['candidates_id']); ?>" class="btn btn-success">Click Here to Vote <?php echo $candidates_item['candidates_parties']; ?></a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>