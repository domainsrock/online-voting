<html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Online Voting</title>
        <link rel="icon" href="<?php echo base_url('images/icon.png'); ?>" />
        <link rel="stylesheet" href="<?php echo base_url('css/bootstrap.min.css'); ?>" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
        <!-- data tables css -->
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css" />
    </head>

    <body class="bg-info">
        <div style="background: #000000; display: block; color: #a0a0a0; padding: 5px; text-align: right; font-family: Cambria; font-weight: bold; font-size: 12px"><i class="fa fa-phone-volume"></i> <a href="tel:+919369791940" style="color: #a0a0a0">+919369791940</a> | <i class="fa fa-envelope"></i> <a href="mailto:info@oskrealty.com" style="color: #a0a0a0">info@oskrealty.com</a></div>

        <nav class="navbar navbar-default" style="border-radius: 0px; font-family: Cambria; font-weight: bold">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <img src="<?php echo base_url('images/logo.jpg'); ?>" width="42" height="42" />
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="<?php echo site_url('admin'); ?>">Dashboard</a></li>
                        <li><a href="<?php echo site_url('admin/voters'); ?>">Voters</a></li>
                        <li><a href="<?php echo site_url('admin/positions'); ?>">Positions</a></li>
                        <li><a href="<?php echo site_url('admin/candidates'); ?>">Candidates</a></li>
                        <li><a href="<?php echo site_url('admin/logout'); ?>">Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">