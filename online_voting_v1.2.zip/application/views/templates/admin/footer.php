<br style="margin-top: 10px"/>
</div>
<div style="background: #202020; min-height: 200px; padding: 20px; color: white; font-family: Cambria;">
        <div class="row">            
            <div class="col-sm-4">
                <br />
                <strong>Quick Links</strong>
                <a href="/index.aspx" style="border-bottom: 1px solid silver; padding: 10px; display: block; font-weight: bold; color: #a0a0a0">Home</a>
                <a href="/storefront/aboutus.aspx" style="border-bottom: 1px solid silver; padding: 10px; display: block; font-weight: bold; color: #a0a0a0">About Us</a>
                <a href="/storefront/contactus.aspx" style="border-bottom: 1px solid silver; padding: 10px; display: block; font-weight: bold; color: #a0a0a0">Contact Us</a>
            </div>
            <div class="col-sm-4">
                <br />
                <strong>Our Services</strong><br />                
                <a href="/storefront/gallery.aspx" style="border-bottom: 1px solid silver; padding: 10px; display: block; font-weight: bold; color: #a0a0a0">Gallery</a>
                <a href="/storefront/projects.aspx" style="border-bottom: 1px solid silver; padding: 10px; display: block; font-weight: bold; color: #a0a0a0">Plots List</a>
                <a href="/storefront/downloads.aspx" style="border-bottom: 1px solid silver; padding: 10px; display: block; font-weight: bold; color: #a0a0a0">Downloads</a>
            </div>
            <div class="col-sm-4">
                <br />
                <strong>Address</strong><br /> 28, Lokpur, Naini, Prayagraj (Allahabad) - 211008<br /><br />
                <strong>Phone</strong><br />+91 9369791940<br /><br />
                <strong>Email</strong><br />info@oskrealty.com
            </div>
        </div>
    </div>
    <div style="background: #000000; color: #a0a0a0; padding-left: 100px; font-weight: bold; text-align: center">
        Copyrights &copy; 2019 - Online Voting. All Rights Reserved.
    </div>
    
    <script src="<?php echo base_url('js/jquery-1.12.4.min.js'); ?>"></script>
    <script src="<?php echo base_url('js/bootstrap.min.js'); ?>"></script>
    <!-- data table javascripts -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$(document).ready(function() { $('#example').DataTable(); } );</script>
</body>
</html>