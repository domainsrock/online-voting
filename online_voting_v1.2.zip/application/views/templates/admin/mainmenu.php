<!-- Fixed navbar -->
<nav class="navbar navbar-inverse" style="border-radius: 0">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle Navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo site_url(); ?>">Online Voting</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="<?php echo site_url('users'); ?>">Dashboard</a></li>
            <li><a href="<?php echo site_url('users/logout'); ?>">Logout</a></li>            
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>