<?php

function find_age_using_dob($dob)
{
    // function to initialize current date and fetch date of birth
    $rdate = new DateTime($dob); $tdate = new DateTime('today');

    // function to find age using date of birth and current date
    $result = $rdate->diff($tdate)->y; return $result;
}