<?php
class Positions_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }

    public function count_positions()
    {
        return $this->db->count_all('positions');
    }

    public function lists_positions()
    {
        $query = $this->db->get('positions');
        return $query->result_array();
    }  
    
    public function getid_positions($positions_slug)
    {
        $query = $this->db->get_where('positions', array('positions_slug' => $positions_slug));
        return $query->row_array();
    } 
    
    public function getid_positions_using_name($positions_name)
    {
        $query = $this->db->get_where('positions', array('positions_name' => $positions_name));
        return $query->row_array();
    } 
}