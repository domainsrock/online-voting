<?php
class Candidates_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }

    public function count_candidates()
    {
        return $this->db->count_all('candidates');
    }

    public function lists_candidates()
    {
        $query = $this->db->get('candidates');
        return $query->result_array();
    }  
    
    public function vote_candidates($candidates_id)
    {
        $this->db->set('candidates_usersvote', 'candidates_usersvote+1', FALSE);
        $this->db->where('candidates_id', $candidates_id);
        $this->db->update('candidates');
    } 

    public function record_vote_candidates($votersid, $positions_id, $candidates_id)
    {
        $voterecords = array (
            'voters_uid' => $votersid,
            'voters_positions' => $positions_id,
            'voters_candidates' => $candidates_id
        );

        $this->db->insert('usersvote', $voterecords);
    }
    
    public function lists_candidates_in_positions($positions)
    {
        $query = $this->db->get_where('candidates', array('candidates_positions' => $positions));
        return $query->result_array();
    } 
    
    public function get_candidates_using_id($candidates_id)
    {
        $query = $this->db->get_where('candidates', array('candidates_id' => $candidates_id));
        return $query->row_array();
    }

    public function isexist_voting_records($voters_id, $positions_id)
    {
        $query = $this->db->get_where('usersvote', array('voters_uid' => $voters_id, 'voters_positions' => $positions_id));
        if($query->num_rows()) { return true; } else { return false; }
    } 
}