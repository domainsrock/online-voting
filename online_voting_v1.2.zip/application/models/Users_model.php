<?php
class Users_model extends CI_Model {

    // function to create default construct to load database in all function
    public function __construct()
    {
        $this->load->database();
    }

    // function to count all registered users
    public function get_count()
    {
        return $this->db->count_all('users');
    }

    // function to check users mobile exist or not
    public function isexist_mobile($phone)
    {
        $query = $this->db->get_where('users', array('phone' => $phone));
        if($query->num_rows()) { return true; } else { return false; }
    }

    // function to check users loginid exist or not
    public function isexist_username($loginid)
    {
        $query = $this->db->get_where('users', array('username' => $loginid));
        if($query->num_rows()) { return true; } else { return false; }
    }

    // function to check users login details is correct or not
    public function loginok($username, $password)
    {
        $query = $this->db->get_where('users', array('username' => $username, 'password' => $password));
        if($query->num_rows()) { return true; } else { return false; }
    }

    // function to create new users using sended usersdata from registration form
    public function create_users($usersdata)
    {
        $this->db->insert('users', $usersdata);
    }

    // function to show list of registered users
    public function lists_users()
    {
        $query = $this->db->get('users');
        return $query->result_array();
    }  
}