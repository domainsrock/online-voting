<?php
class Admin_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }

    public function get_count()
    {
        return $this->db->count_all('admin');
    }

    public function loginok($username, $password)
    {
        $query = $this->db->where(['username'=>$username,'password'=>$password])
                      ->get('admin');

        if($query->num_rows()) { return true; } else { return false; }
    }
}