<?php
class Users extends CI_Controller {

    public function __construct()
    {
        // required library and helpers
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->helper('url_helper');
        $this->load->library('pagination');
        $this->load->library('form_validation');

        // models to be used in this contollers
        $this->load->model('users_model');
        $this->load->model('positions_model');
        $this->load->model('candidates_model');

        // function to get values from session for users login
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');
        $users_loginsok = $this->session->userdata('users_loginsok');

        // function to redirect non-logged users to login page
        if($users_loginsok == false) { return redirect('users/login'); } else { }
    }

    public function index()
    {
        $data['positions'] = $this->positions_model->lists_positions();

        $this->load->view('templates/users/header1');
		$this->load->view('users/index', $data);
        $this->load->view('templates/users/footer');
    }

    public function vote($positions_slug)
    {
        // fetching values of username from session
        $username = $this->session->userdata('users_username');
        $data['positions'] = $this->positions_model->getid_positions($positions_slug);

        if($this->candidates_model->isexist_voting_records($username, $data['positions']['positions_id']))
        {
            echo '<script>alert("you are already voted for '.$data['positions']['positions_name'].' and your votes has been recorded."); window.location = "'.site_url('users').'";</script>';
        }
        else
        {
            $data['candidates'] = $this->candidates_model->lists_candidates_in_positions($data['positions']['positions_name']);

            $this->load->view('templates/users/header1');
		    $this->load->view('users/candidates', $data);
            $this->load->view('templates/users/footer');
        }
    }

    public function votings($candidates_id)
    {
        // fetching values of username from session
        $username = $this->session->userdata('users_username');

        // function to find requested candidates details
        $candidatesinfo = $this->candidates_model->get_candidates_using_id($candidates_id);
        $positionsinfo = $this->positions_model->getid_positions_using_name($candidatesinfo['candidates_positions']);

        // function to updates votes and records votings records
        $this->candidates_model->vote_candidates($candidates_id);
        $this->candidates_model->record_vote_candidates($username, $positionsinfo['positions_id'], $candidates_id);
        echo '<script>alert("thanks you for votings! your votes has been recorded."); window.location = "'.site_url('users').'";</script>';
    }

    public function logout()
    {
        // function to users logout
        $this->session->sess_destroy();
        return redirect('users/login');
    }
}