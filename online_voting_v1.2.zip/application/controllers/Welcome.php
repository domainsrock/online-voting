<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->helper('url_helper');
        $this->load->library('pagination');
        $this->load->library('form_validation');
    }

	public function index()
	{
		$this->load->view('templates/header');
		$this->load->view('templates/index');
		$this->load->view('templates/footer');
	}
}
