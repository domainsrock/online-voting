<?php
class Admin extends CI_Controller {

    public function __construct()
    {
        // required library and helpers
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->helper('url_helper');
        $this->load->library('pagination');
        $this->load->library('form_validation');

        // models to be used in this contollers
        $this->load->model('admin_model');
        $this->load->model('users_model');
        $this->load->model('positions_model');
        $this->load->model('candidates_model');

        // function to get values from session for users login
        $admin_username = $this->session->userdata('admin_username');
        $admin_password = $this->session->userdata('admin_password');
        $admin_loginsok = $this->session->userdata('admin_loginsok');

        // function to redirect non-logged users to login page
        if($admin_loginsok == false) { return redirect('admin/login'); } else { }
    }

    public function index()
    {
        $this->load->view('templates/admin/header1');
		$this->load->view('admin/index');
        $this->load->view('templates/admin/footer');
    }

    public function positions()
    {
        // function to fetch positions list from database
        $data['positions'] = $this->positions_model->lists_positions();

        $this->load->view('templates/admin/header1');
		$this->load->view('admin/positions', $data);
        $this->load->view('templates/admin/footer');
    }

    public function voters()
    {
        // function to fetch positions list from database
        $data['voters'] = $this->users_model->lists_users();

        $this->load->view('templates/admin/header1');
		$this->load->view('admin/voters', $data);
        $this->load->view('templates/admin/footer');
    }

    public function candidates()
    {
        // function to fetch positions list from database
        $data['candidates'] = $this->candidates_model->lists_candidates();

        $this->load->view('templates/admin/header1');
		$this->load->view('admin/candidates', $data);
        $this->load->view('templates/admin/footer');
    }

    public function logout()
    {
        // function to users logout
        $this->session->sess_destroy();
        return redirect('admin/login');
    }
}