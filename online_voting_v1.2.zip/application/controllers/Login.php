<?php
class Login extends CI_Controller {

    public function __construct()
    {
        // required library and helpers
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->helper('date');
        $this->load->library('session');
        $this->load->helper('url_helper');
        $this->load->library('pagination');
        $this->load->library('form_validation');

        // models to be used in this contollers
        $this->load->model('users_model');
        $this->load->model('admin_model');
    }

    public function users()
    {
        // function to get values from session for users login
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');
        $users_loginsok = $this->session->userdata('users_loginsok');
        $data['title'] = "Voters Login";

        // function to redirect non-logged users to login page
        if($users_loginsok) { return redirect('users'); }
        else
        {
            $this->form_validation->set_rules('users_username','Username','required');
            $this->form_validation->set_rules('users_password','Password','required|max_length[12]');
            $this->form_validation->set_error_delimiters('<div class="alert alert-danger">','</div>');

            if ($this->form_validation->run() === FALSE)
            {
                $data['response'] = "";
                $this->load->view('templates/users/header2', $data);
                $this->load->view('users/login', $data);
                $this->load->view('templates/users/footer');
            }
            else
            {
              $data['users_username'] = $this->input->post('users_username');
              $data['users_password'] = $this->input->post('users_password');

              if($this->users_model->loginok($data['users_username'], $data['users_password']))
              {
                // function to set session for login details
                $logindata = array('users_username' => $data['users_username'],'users_password' => $data['users_password'], 'users_loginsok' => true);
                $this->session->set_userdata($logindata);

                // function to redirect on dashboard after login validation
                return redirect('users');
              }
              else
              {
                $data['response'] = '<div class="alert alert-danger"><b>Error!</b> Invalid Login Details.</div>';
                $this->load->view('templates/header1', $data);
		            $this->load->view('users/login', $data);
                $this->load->view('templates/footer');
              }
            }
        }
    }

    public function admin()
    {
        // function to get values from session for admin login
        $admin_username = $this->session->userdata('admin_username');
        $admin_password = $this->session->userdata('admin_password');
        $admin_loginsok = $this->session->userdata('admin_loginsok');
        $data['title'] = "Administrator Login";

        // function to redirect non-logged users to admin page
        if($admin_loginsok) { return redirect('admin'); }
        else
        {
            $this->form_validation->set_rules('admin_username','Username','required');
            $this->form_validation->set_rules('admin_password','Password','required|max_length[12]');
            $this->form_validation->set_error_delimiters('<div class="alert alert-danger">','</div>');

            if ($this->form_validation->run() === FALSE)
            {
                $data['response'] = "";
                $this->load->view('templates/admin/header2', $data);
                $this->load->view('admin/login', $data);
                $this->load->view('templates/admin/footer2');
            }
            else
            {
              $data['admin_username'] = $this->input->post('admin_username');
              $data['admin_password'] = $this->input->post('admin_password');

              if($this->admin_model->loginok($data['admin_username'], $data['admin_password']))
              {
                // function to set session for login details
                $logindata = array('admin_username' => $data['admin_username'],'admin_password' => $data['admin_password'], 'admin_loginsok' => true);
                $this->session->set_userdata($logindata);

                // function to redirect on dashboard after login validation
                return redirect('admin');
              }
              else
              {
                $data['response'] = '<div class="alert alert-danger"><b>Error!</b> Invalid Login Details.</div>';
                $this->load->view('templates/admin/header2', $data);
		            $this->load->view('admin/login', $data);
                $this->load->view('templates/admin/footer2');
              }
            }
        }
    }

    public function newusers()
    {
        // function to get values from session for users login
        $users_username = $this->session->userdata('users_username');
        $users_password = $this->session->userdata('users_password');
        $users_loginsok = $this->session->userdata('users_loginsok');
        $data['title'] = "Voters Account Registration";

        // function to redirect non-logged users to login page
        if($users_loginsok) { return redirect('users'); }
        else
        {
            $this->form_validation->set_rules('users_fname','First Name','required');
            $this->form_validation->set_rules('users_lname','Last Name','required');
            $this->form_validation->set_rules('users_phone','Phone Number','required');
            $this->form_validation->set_rules('users_dob','Date of Birth','required');
            $this->form_validation->set_rules('users_genders','Gender','required');
            $this->form_validation->set_rules('users_address','Address','required');
            $this->form_validation->set_rules('users_password1','Password','required|min_length[6]|max_length[12]');
            $this->form_validation->set_rules('users_password2','Confirm Password','required|min_length[6]|max_length[12]');
            $this->form_validation->set_error_delimiters('<div class="alert alert-danger">','</div>');

            if ($this->form_validation->run() === FALSE)
            {
                $data['response'] = "";
                $this->load->view('templates/users/header2', $data);
                $this->load->view('users/signup', $data);
                $this->load->view('templates/users/footer');
            }
            else
            {
              // function to fetch values from registration form
              $data['users_fname'] = $this->input->post('users_fname');
              $data['users_lname'] = $this->input->post('users_lname');
              $data['users_phone'] = $this->input->post('users_phone');
              $data['users_dob'] = $this->input->post('users_dob');
              $data['users_genders'] = $this->input->post('users_genders');
              $data['users_address'] = $this->input->post('users_address');
              $data['users_password1'] = $this->input->post('users_password1');
              $data['users_password2'] = $this->input->post('users_password2');

              // function to validate password and confirm password
              if($data['users_password1'] == $data['users_password2'])
              {
                if($this->users_model->isexist_mobile($data['users_phone']))
                {
                  $data['response'] = '<div class="alert alert-danger"><b>Error!</b> Phone number is already exist.</div>';
                  $this->load->view('templates/users/header2', $data);
		              $this->load->view('users/signup', $data);
                  $this->load->view('templates/users/footer');
                }
                else
                {
                  // function to calculate age from date of birth
                  $data['users_age'] = find_age_using_dob($data['users_dob']);
                  $date['users_username'] = $data['users_phone'];

                  if($data['users_age']>=18)
                  {
                    // creating array for users account registration
                    $usersdata = array(
                      'username' => $date['users_username'],
                      'password' => $data['users_password1'],
                      'fname' => $data['users_fname'],
                      'lname' => $data['users_lname'],
                      'phone' => $data['users_phone'],
                      'gender' => $data['users_genders'],
                      'age' => $data['users_age'],
                      'birthday' => $data['users_dob'],
                      'address' => $data['users_address']
                    );

                    // function to set session for login details
                    $this->users_model->create_users($usersdata);

                    // function to redirect on dashboard after login validation
                    echo "<script>alert('account registration is successful. please login now'); window.location = 'login';</script>";
                  }
                  else
                  {
                    $data['response'] = '<div class="alert alert-danger"><b>Error!</b> You are not able to Register for Vote. Your Age is Less than 18.</div>';
                    $this->load->view('templates/users/header2', $data);
		                $this->load->view('users/signup', $data);
                    $this->load->view('templates/users/footer');
                  }
                }
              }
              else
              {
                $data['response'] = '<div class="alert alert-danger"><b>Error!</b> Password and Confirm Password should be Same</div>';
                $this->load->view('templates/users/header2', $data);
		            $this->load->view('users/signup', $data);
                $this->load->view('templates/users/footer');
              }
            }
        }
    }
}