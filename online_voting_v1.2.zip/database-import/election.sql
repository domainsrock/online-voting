-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 13, 2019 at 03:46 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `election`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `registrationdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `mobile`, `username`, `password`, `registrationdate`) VALUES
(1, 'admin@admin.com', '9876543210', 'admin@admin.com', '9876543210', '2019-04-12 08:27:03');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
CREATE TABLE IF NOT EXISTS `candidates` (
  `candidates_id` int(11) NOT NULL AUTO_INCREMENT,
  `candidates_name` varchar(20) NOT NULL,
  `candidates_parties` varchar(20) NOT NULL,
  `candidates_images` varchar(20) NOT NULL,
  `candidates_positions` varchar(20) NOT NULL,
  `candidates_usersvote` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`candidates_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`candidates_id`, `candidates_name`, `candidates_parties`, `candidates_images`, `candidates_positions`, `candidates_usersvote`) VALUES
(1, 'Luis Nani', 'BJP', 'bjp.jpg', 'Chairperson', 1),
(2, 'Wayne Rooney', 'Congress', 'congress.png', 'Treasurer', 0),
(3, 'Thomas Vaemalen', 'BSP', 'bsp.jpg', 'Chairperson', 0),
(4, 'Michael Walters', 'BJP', 'bjp.jpg', 'Vice-Secretary', 0),
(5, 'Roberto Mancini', 'Congress', 'congress.png', 'Secretary', 1);

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
CREATE TABLE IF NOT EXISTS `positions` (
  `positions_id` int(11) NOT NULL AUTO_INCREMENT,
  `positions_slug` varchar(50) NOT NULL,
  `positions_name` varchar(20) NOT NULL,
  PRIMARY KEY (`positions_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`positions_id`, `positions_slug`, `positions_name`) VALUES
(1, 'chairperson', 'Chairperson'),
(2, 'secretary', 'Secretary'),
(3, 'vice-secretary', 'Vice-Secretary'),
(4, 'organizing-secretary', 'Organizing-Secretary'),
(5, 'treasurer', 'Treasurer'),
(6, 'vice-treasurer', 'Vice-Treasurer'),
(7, 'vice-chairperson', 'Vice-Chairperson'),
(8, 'hod', 'HOD');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL DEFAULT '123456',
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `birthday` date NOT NULL,
  `age` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fname`, `lname`, `phone`, `gender`, `birthday`, `age`, `address`, `regdate`) VALUES
(4, '9876543211', '123456', 'ram', 'sharma', '9876543211', 'Male', '2000-12-04', 18, 'Allahabad', '2019-04-12 16:03:40'),
(3, '9876543210', '123456', 'Ramesh', 'Singh', '9876543210', 'Male', '2001-12-04', 17, 'Allahabad', '2019-04-12 15:56:40');

-- --------------------------------------------------------

--
-- Table structure for table `usersvote`
--

DROP TABLE IF EXISTS `usersvote`;
CREATE TABLE IF NOT EXISTS `usersvote` (
  `voters_sid` int(11) NOT NULL AUTO_INCREMENT,
  `voters_uid` int(11) NOT NULL,
  `voters_positions` int(11) NOT NULL,
  `voters_candidates` int(11) NOT NULL,
  `voters_votingdates` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`voters_sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
